
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout 
from django_codedigo.forms import SignupForm, LoginForm
from django.http import JsonResponse
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt

# Create your views here.



#NAVBAR
def index(request):
    return render(request, 'codedigo/index.html')

def challenges(request):
    return render(request, 'codedigo/challenges.html')

def exercise(request):
    return render(request, 'codedigo/exercise.html')

def leaderboards(request):
    return render(request, 'codedigo/leaderboards.html')

def tutorials(request):
    return render(request, 'codedigo/tutorials.html')

#==============================================================


#PROGRAMMING TUTORIALS
def cpp_tutorial(request):
    return render(request, 'codedigo/cpp_tutorial.html')


# signup page
def user_signup(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = SignupForm()
    return render(request, 'codedigo/signup.html', {'form': form})

# login page
def user_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user:
                login(request, user)    
                return redirect('home')
    else:
        form = LoginForm()
    return render(request, 'codedigo/login.html', {'form': form})

# logout page
def user_logout(request):
    logout(request)
    return redirect('login')

# Login view: Generate OTP and send it via SMS
@csrf_exempt  # Only for API request handling
def send_otp_view(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        phone_number = data.get('phone_number')

        if phone_number:
            otp = generate_otp()
            request.session['otp'] = otp  # Store the OTP in session

            # Send OTP via Twilio
            send_otp_via_sms(phone_number, otp)

            return JsonResponse({'success': True})
        else:
            return JsonResponse({'success': False, 'error': 'Invalid phone number'})

    return JsonResponse({'success': False, 'error': 'Invalid request method'})

# OTP Verification View
def verify_otp_view(request):
    if request.method == 'POST':
        entered_otp = ''.join([request.POST.get(f'otp{i}') for i in range(1, 7)])
        saved_otp = request.session.get('otp')

        if entered_otp == saved_otp:
            messages.success(request, "OTP verified successfully!")
            return redirect('home')
        else:
            messages.error(request, "Invalid OTP. Please try again.")

    return render(request, 'verify_otp.html')

