from django.apps import AppConfig


class CodedigoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'codedigo'
