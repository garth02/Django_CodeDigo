

function requestOTP() {
    const phoneNumber = document.getElementById('phone_number').value;
    if (phoneNumber) {
        // Hide login form and show OTP form
        document.getElementById('login-form').style.display = 'none';
        document.getElementById('otp-form').style.display = 'block';

        // In a real scenario, you would send the OTP to the user's phone here.
        fetch('/send-otp', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': '{{ csrf_token }}'  // Django CSRF token
            },
            body: JSON.stringify({ phone_number: phoneNumber })
        }).then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('OTP has been sent to your phone.');
            } else {
                alert('Failed to send OTP.');
            }
        });
    } else {
        alert('Please enter a valid phone number.');
    }
}

// Function to move focus to the next input field
function moveToNext(currentInput, nextInputId) {
    if (currentInput.value.length === 1 && nextInputId) {
        document.getElementById(nextInputId).focus();
    }
}

// Mock function to simulate OTP resend
function resendOTP() {
    alert("A new OTP has been sent to your phone.");
}