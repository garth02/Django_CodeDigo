// change navbar on scroll

window.addEventListener('scroll', () => {
    document.querySelector('nav').classList.toggle('window-scroll', window.scrollY > 0)
})


// Show/hide faq questions 

const faqs = document.querySelectorAll('.faq');

faqs.forEach(faq => {
    faq.addEventListener('click', () => {
        faq.classList.toggle('open');

        //change icon
        const icon = faq.querySelector('.faq__icon i');
        if(icon.className === 'fa-solid fa-plus'){
            icon.className =  'fa-solid fa-minus';   
        }else{
            icon.className = 'fa-solid fa-plus';
        }
    })
});


//show/hide navbar

const menu = document.querySelector(".nav_menu");
const menuBtn = document.querySelector("#open-menu-btn");
const closeBtn = document.querySelector("#close-menu-btn");

menuBtn.addEventListener('click', () => {
    menu.style.display = "flex";
    closeBtn.style.display = "inline-block";
    menuBtn.style.display = "none";
})

// close navbar

const closeNav = () =>{
    menu.style.display = "none";
    closeBtn.style.display = "none";
    menuBtn.style.display = "inline-block";
}

closeBtn.addEventListener('click', closeNav)

document.addEventListener('DOMContentLoaded', () => {
    const openMenuBtn = document.getElementById('open-menu-btn');
    const closeMenuBtn = document.getElementById('close-menu-btn');
    const navMenu = document.querySelector('.nav_menu');

    openMenuBtn.addEventListener('click', () => {
        navMenu.classList.add('show');
    });

    closeMenuBtn.addEventListener('click', () => {
        navMenu.classList.remove('show');
    });
});

//rewards--------------------------------------

function openModal() {
    document.getElementById('rewardModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('rewardModal').style.display = 'none';
}

function claimReward() {
    alert('Reward claimed successfully!');
    closeModal();
}

// Close the modal if the user clicks outside of it
window.onclick = function(event) {
    var modal = document.getElementById('rewardModal');
    if (event.target == modal) {
        closeModal();
    }
}

